import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import utils.EcommerceAPI;
import utils.config.Config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@RestController
@RequestMapping("/categories/{category}/products")
public class ProductController {

    @Autowired
    private EcommerceAPI ecommerceAPI;

    @Autowired
    private Config config;

    @Autowired
    private ObjectMapper objectMapper;

    private String generateProductId(ObjectNode product, String company) {
        return company + "_" + product.get("productName").asText().replace(" ", "_");
    }

    @GetMapping
    public ResponseEntity<List<ObjectNode>> getTopProducts(
            @PathVariable String category,
            @RequestParam(defaultValue = "10") int n,
            @RequestParam(defaultValue = "0") double minPrice,
            @RequestParam(defaultValue = "Infinity") double maxPrice,
            @RequestParam(required = false) String sortBy,
            @RequestParam(defaultValue = "asc") String order,
            @RequestParam(defaultValue = "1") int page
    ) {
        System.out.println("Fetching products for category: " + category);
        List<ObjectNode> allProducts = new ArrayList<>();
        for (String company : config.getCompanies()) {
            List<ObjectNode> products = ecommerceAPI.fetchProducts(company, category, n, minPrice, maxPrice);
            System.out.println("Fetched " + products.size() + " products from " + company);
            for (ObjectNode product : products) {
                product.put("id", generateProductId(product, company));
                product.put("company", company);
            }
            allProducts.addAll(products);
        }
        System.out.println("Total products fetched: " + allProducts.size());

        if (sortBy != null) {
            boolean reverse = order.equalsIgnoreCase("desc");
            allProducts.sort(Comparator.comparing(p -> p.get(sortBy).asDouble(), reverse ? Comparator.reverseOrder() : Comparator.naturalOrder()));
        }

        int start = (page - 1) * config.getMaxProductsPerPage();
        int end = Math.min(start + config.getMaxProductsPerPage(), allProducts.size());
        List<ObjectNode> paginatedProducts = allProducts.subList(start, end);

        return ResponseEntity.ok(paginatedProducts);
    }

    @GetMapping("/{productId}")
    public ResponseEntity<ObjectNode> getProductDetails(
            @PathVariable String category,
            @PathVariable String productId
    ) {
        for (String company : config.getCompanies()) {
            List<ObjectNode> products = ecommerceAPI.fetchProducts(company, category, 10, 0, Double.MAX_VALUE);
            for (ObjectNode product : products) {
                if (generateProductId(product, company).equals(productId)) {
                    product.put("id", generateProductId(product, company));
                    product.put("company", company);
                    return ResponseEntity.ok(product);
                }
            }
        }
        ObjectNode response = objectMapper.createObjectNode();
        response.put("message", "Product not found");
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
    }
}

